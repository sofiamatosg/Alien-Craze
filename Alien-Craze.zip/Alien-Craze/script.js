/* VARIABLES */
let catcher, fallingObject, pts, fallingVel, button, dog;
let gameOver = false;

/* PRELOAD LOADS FILES */
function preload() {
  dog = loadImage("assets/dog.png");
  alien = loadImage("assets/alienbad.png");
}

/* SETUP RUNS ONCE */
function setup() {
  createCanvas(400, 400);
  pts = 0;
  fallingVel = 5;

  // Create catcher
  catcher = new Sprite(dog, 200, 380, 100, 20);
  catcher.color = color(95, 158, 160);
  dog.resize(80, 0);
  catcher.collider = "k";

  // Create falling object
  fallingObject = new Sprite(100, 0, 20);
  fallingObject.color = color(0, 128, 128);

  //badFallingObject = new Sprite(alien, 100, 0, 20);
  
  
  
  // Create button
  button = new Sprite(300, 300);
  button.w = 100;
  button.h = 50;
  button.text = "Loser! \n Try again";
  button.color = "plum";
  button.collider = "k";
  button.pos = { x: -300, y: -300 };
}

/* RESTART FUNCTION */
function restartGame() {
  pts = 0;
  fallingVel = 5;
  catcher.pos = { x: 200, y: 380 };
  fallingObject.pos = { x: random(50, 350), y: 0 };
  button.pos = { x: -300, y: -300 };
  gameOver = false;
}

/* DRAW LOOP REPEATS */
function draw() {
  background(19, 20, 66);

  if (gameOver) {
    button.pos = { x: width / 2, y: height / 2 };
    if (button.mouse.presses()) {
      print("pressed");
      restartGame();
    }
    return;
  }

  // Falling object behavior
  fallingObject.vel.y = random(2, fallingVel);
  let c = random(["blue", "yellow", "pink", "red", "purple", "green"]);
  fallingObject.color = color(c);

  // If fallingObject reaches bottom, trigger game over
  if (fallingObject.y > height) {
    fallingObject.y = 0;
    fallingObject.pos = { x: 500, y: 500 };
    catcher.pos = { x: 500, y: 500 };
    gameOver = true;
  }

  // Collision detection
  if (fallingObject.collides(catcher)) {
    fallingObject.y = 0;
    fallingObject.x = random(1, width);
    pts += 1;

    if (fallingVel <= 21.5) {
      fallingVel += 0.5;
    }
    fallingObject.direction = "down";
  }
  catcher.moveTowards(mouse.x, 350, 0.10);

  // Stop catcher at edges
  if (catcher.x < 50) {
    catcher.x = 50;
  } else if (catcher.x > 350) {
    catcher.x = 350;
  }

  // Draw UI
  fill("white");
  text("Score: " + pts, 30, 20);
  textSize(12);
  text("Move the \nalien dog with the mouse \nto catch the falling \nspace balls.", width - 150, 20);
}